export const fn = () => {}

fn.prototype = fn
