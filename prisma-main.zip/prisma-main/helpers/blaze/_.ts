/* eslint-disable @typescript-eslint/no-unsafe-argument */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { A } from 'ts-toolbelt'

const _ = Symbol('_') as A.x

export { _ }
