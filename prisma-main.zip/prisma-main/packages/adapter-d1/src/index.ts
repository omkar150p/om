export { PrismaD1 } from './d1'
