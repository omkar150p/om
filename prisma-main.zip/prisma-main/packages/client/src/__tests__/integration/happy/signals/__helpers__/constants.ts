export const READY_MESSAGE = 'ready'
export const EXIT_MESSAGE = 'exit'
