export { PrismaClient, User } from '@prisma/client'
